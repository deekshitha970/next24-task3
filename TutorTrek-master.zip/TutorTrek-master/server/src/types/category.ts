export interface CategoryInterface {
    name: string;
    description: string;
    createdAt?: Date;
    updatedAt?: Date;
  }
  