import React from "react";

type Props = {};

const InstructorChannels: React.FC = (props: Props) => {
  return <div className="flex p-5 text-xl items-center justify-center">Coming soon...</div>;
};

export default InstructorChannels;
