import React from "react";
const AboutLesson: React.FC<{ about: string }> = ({ about }) => {
  return <div>{about}</div>;
};

export default AboutLesson;
