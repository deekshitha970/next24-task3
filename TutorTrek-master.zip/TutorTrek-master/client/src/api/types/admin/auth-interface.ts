export interface AdminLoginInfo {
    email:string;
    password:string;
}