export const plugins = [
  require('tailwindcss'),
  require('autoprefixer'),
];
